import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class NumberleModelTest {
    @Test
    void numberleModelCreateTest(){
        //This test aim to test whether the NumberleModel pick an equation to guess.
        NumberleModel model = new NumberleModel();

        NumberleController controller = new NumberleController(model);

        controller.processInput("Game Started");

        NumberleGUIView guiView = new NumberleGUIView(model);

        assertNull(model.getCurrentEquation());

        model.startGame();
        String testEquation;
        testEquation = model.getCurrentEquation();
        assertNotNull(model.getCurrentEquation());

        model.resetGame();
        assertNotEquals(testEquation, model.getCurrentEquation());
    }
}