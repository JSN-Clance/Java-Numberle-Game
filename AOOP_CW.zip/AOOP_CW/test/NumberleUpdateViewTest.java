import org.junit.jupiter.api.Test;

class NumberleUpdateViewTest {

    @Test
    void testLaunchCLI() {
        NumberleModel model = new NumberleModel();
        NumberleController controller = new NumberleController(model);
        controller.processInput("Game Started");
        NumberleCLIView CLIView = new NumberleCLIView(model);

    }

}