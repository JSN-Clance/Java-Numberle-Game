import org.junit.jupiter.api.Test;

class NumberleNewGameTest {

    @Test
    void NumberleGUITest() {
        //Aim to test init() Function work with compile issue.
        NumberleModel model = new NumberleModel();
        NumberleController controller = new NumberleController(model);
        controller.processInput("Game Started");
        NumberleGUIView guiView = new NumberleGUIView(model);

    }
}