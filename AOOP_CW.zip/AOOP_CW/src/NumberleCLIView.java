import java.util.Scanner;

public class NumberleCLIView implements Observer {
    private NumberleModel model; // Model component holding the game logic and data
    private boolean CILActive = false; // Flag to check if the CLI is currently active
    private Scanner scanner = new Scanner(System.in);
    private String input; // Variable to hold user input

    public NumberleCLIView(NumberleModel model) {
        this.model = model;
        model.addObserver(this); // Register this view as an observer of the model
        launchCLI(); // Start the command line interface
    }

    // Launches the command line interface and initializes the game if not already started
    public void launchCLI() {
        CILActive = true;
        // Check if the game has not started and initiate it
        if (model.getCurrentEquation() == null) {
            model.startGame();
            System.out.println("Current Start Model: CLI model.");
        }
        System.out.println("CLI Mode Activated. Type your equation guess or 'GUI' to switch to the New GUI Game");
        handleInput(); // Begin handling user input from the command line
    }

    // Handles user input continuously until the CLI is deactivated
    private void handleInput() {
        while (CILActive && scanner.hasNextLine()) {
            input = scanner.nextLine();
            if (input.equalsIgnoreCase("GUI")) {
                deactivate(); // Switch off CLI mode
                // Switch to GUI mode by creating and displaying the GUI view
                java.awt.EventQueue.invokeLater(() -> new NumberleGUIView(model).setVisible(true));
                break; // Exit the input loop
            } else {
                // Submit user guess to the model
                model.CILSubmitGuess(input);
            }
        }
    }

    // Deactivates the CLI mode
    private void deactivate() {
        CILActive = false;
    }

    // Updates the CLI view based on changes in the model
    @Override
    public void update() {
        if (CILActive) {
            // Print the current state of the equation after an update from the model
            System.out.println("Updated CLI display: Current Equation - " + model.getCurrentEquation());
        }
//        // Check if the user's input matches the current equation (successful guess)
//        if (input.equals(model.getCurrentEquation())) {
//            System.out.println("WOW! You guessed the right Equation, Wonderful!");
//        }
    }

    public static void main(String[] args) {
        NumberleModel model = new NumberleModel();
        NumberleController controller = new NumberleController(model);
        controller.processInput("Game Started");
        NumberleCLIView CLIView = new NumberleCLIView(model);
    }
}
