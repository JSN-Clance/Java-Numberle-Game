public class NumberleController {
    private NumberleModel model;

    public NumberleController(NumberleModel model) {
        this.model = model;
    }

    // Processes the input received and performs actions based on the type of input
    public void processInput(String input) {
        input = input.trim(); // Trim the input to remove leading and trailing spaces
        // If input is 'new', reset the game to its initial state
        if (input.equalsIgnoreCase("new")) {
            model.resetGame();
        } else if (isValidEquation(input)) {
            model.submitGuess(input); // If the input is a valid equation, submit the guess to the model
        } else if (input.equalsIgnoreCase("Game Started")) {
            // Print a welcome message when the game starts
            System.out.println("Welcome to play the Numberle game.");
        }
    }

    // Checks if the provided string is a valid equation using a regular expression
    private boolean isValidEquation(String input) {
        // The regular expression checks for a pattern of digits, an operator, more digits, an equals sign, and final digits
        return input.matches("[0-9]+[\\+\\-\\*/][0-9]+[\\=][0-9]+");
    }
}
