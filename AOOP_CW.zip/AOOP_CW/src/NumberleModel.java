import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class NumberleModel implements Observable {
    private List<Observer> observers = new ArrayList<>(); // List to hold all observers
    private List<String> equations; // List to store possible equations from a file
    private String currentEquation; // Current equation selected for the game
    private Random random = new Random(); // Random generator for selecting an equation
    private boolean cheatModeActive = false; // Flag to indicate if cheat mode is active

    // Constructor - Loads equations from a file upon instantiation
    public NumberleModel() {
        loadEquations(); // Load equations from a text file
    }

    // Loads equations from a text file
    private void loadEquations() {
        try {
            equations = Files.readAllLines(Paths.get("src/equations.txt")); // Read all lines from the file
        } catch (Exception e) {
            e.printStackTrace(); // Print any errors that occur during file reading
        }
    }

    // Starts a new game by selecting a random equation
    public void startGame() {
        selectRandomEquation(); // Select a random equation
        notifyObservers(); // Notify all observers about the change in state
    }

    // Resets the game to start over with a new equation
    public void resetGame() {
        selectRandomEquation();
        notifyObservers();
    }

    // Selects a random equation from the list
    private void selectRandomEquation() {
        if (!equations.isEmpty()) {
            currentEquation = equations.get(random.nextInt(equations.size()));
        }
    }

    // Submits a guess and returns feedback for each character
    public String submitGuess(String guess) {
        StringBuilder feedback = new StringBuilder();

        // Generate feedback based on the guess compared to the current equation
        for (int i = 0; i < guess.length(); i++) {
            char guessChar = guess.charAt(i);
            if (guessChar == currentEquation.charAt(i)) {
                feedback.append('G'); // Correct character and position
            } else if (currentEquation.contains(String.valueOf(guessChar))) {
                feedback.append('O'); // Correct character but wrong position
            } else {
                feedback.append('X'); // Incorrect character
            }
        }

        return feedback.toString(); // Return the feedback string
    }

    // Returns the current equation
    public String getCurrentEquation() {
        return currentEquation;
    }


    @Override
    public void addObserver(Observer o) {
        if (!observers.contains(o)) {
            observers.add(o);
        }
    }

    @Override
    public void removeObserver(Observer o) {
        observers.remove(o);
    }

    @Override
    public void notifyObservers() {
        for (Observer observer : observers) {
            observer.update();
        }
    }

    // Returns the status of cheat mode
    public boolean isCheatModeActive() {
        return cheatModeActive;
    }

    // Sets the status of cheat mode and notifies observers
    public void setCheatModeActive(boolean cheatModeActive) {
        this.cheatModeActive = cheatModeActive;
        notifyObservers();
    }

    // Processes a guess in CLI mode and provides immediate feedback
    public void CILSubmitGuess(String guess) {
        System.out.println("Guess submitted: " + guess);
        if (guess.equals(currentEquation)) {
            System.out.println("Correct! The equation was: " + currentEquation);
            resetGame();
            System.out.println("Game is updating. Now you can try to have another Numberle Guess!");
        } else {
            System.out.println("Incorrect guess. Try again!");
        }
        notifyObservers();
    }
}
