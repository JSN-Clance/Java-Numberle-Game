import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;

public class NumberleGUIView extends JFrame implements Observer {
    private NumberleModel model; // Model that this view observes
    private JTextArea displayArea;// Text area for displaying game status and messages
    private JPanel keyboardPanel, controlPanel; // Panels for keyboard input and control buttons
    private Map<String, JButton> keyButtons = new HashMap<>(); // Maps button labels to their JButton instances for quick access

    private JButton startGameButton, endButton; // Buttons to start and end the game

    private JTextField[][] inputFields; // Grid of text fields for user input
    private int currentRow = 0; // Track the current row of input
    private int currentColumn = 0; // Track the current column of input

    private String[] currentGuess = new String[7]; // Store the current guess in an array of strings

    public NumberleGUIView(NumberleModel model) {
        this.model = model;
        model.addObserver(this); // Register as an observer
        initUI(); // Initialize the user interface
    }

    private void initUI() {
        setTitle("Numberle Game"); // Window title
        setSize(600, 400); // Window size
        setLocationRelativeTo(null); // Center on screen
        setDefaultCloseOperation(EXIT_ON_CLOSE); // Exit application on close
        setLayout(new BorderLayout()); // Use BorderLayout for main layout

        String greeting = "Welcome to Numberle Game, Have Fun!";
        displayArea = new JTextArea(greeting);
        displayArea.setEditable(false); // Make display area non-editable
        add(new JScrollPane(displayArea), BorderLayout.NORTH); // Add display area with a scroll pane

        setupMenu();
        setupControlPanel();
        keyboardPanel.setVisible(false); //Bug Fix
        setVisible(true);
        setupInputDisplay();
    }

    // Set up the menu bar with options
    private void setupMenu() {
        JMenuBar menuBar = new JMenuBar();
        JMenu menu = new JMenu("Menu");

        // Menu item for switching to CLI mode
        JMenuItem switchToCLIItem = new JMenuItem("Switch to CLI Model");
        switchToCLIItem.addActionListener(this::handleSwitchToCLI);
        menu.add(switchToCLIItem);

        // Menu item for toggling cheat mode
        JMenuItem cheatModeItem = new JMenuItem("Cheat Model");
        cheatModeItem.addActionListener(this::toggleCheatMode);
        menu.add(cheatModeItem);

        // Menu item to end the game
        JMenuItem endGameItem = new JMenuItem("End This Trash Code");
        endGameItem.addActionListener(e -> System.exit(0));
        menu.add(endGameItem);

        menuBar.add(menu);
        setJMenuBar(menuBar);
    }

    // Set up the control panel with buttons
    private void setupControlPanel() {
        controlPanel = new JPanel(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.gridwidth = GridBagConstraints.REMAINDER;
        gbc.fill = GridBagConstraints.HORIZONTAL;

        startGameButton = new JButton("Start Game");
        startGameButton.addActionListener(this::handleStartGame);
        controlPanel.add(startGameButton, gbc);

        endButton = new JButton("End This Trash Code");
        endButton.addActionListener(e -> System.exit(0));
        controlPanel.add(endButton, gbc);

        add(controlPanel, BorderLayout.CENTER);
        setupKeyboard();
        keyboardPanel.setVisible(false);
    }

    // Toggle cheat mode on and off
    private void toggleCheatMode(ActionEvent e) {
        JMenuItem cheatItem = (JMenuItem) e.getSource();
        if (model.isCheatModeActive()) {
            cheatItem.setText("Cheat Model");
            displayArea.setText("Welcome to Numberle Game, Have Fun!");
            model.setCheatModeActive(false);
        } else {
            cheatItem.setText("Cancel Cheat");
            displayArea.setText("Answer: " + model.getCurrentEquation());
            model.setCheatModeActive(true);
        }
    }

    // Set up the input display grid for guesses
    private void setupInputDisplay() {
        JPanel inputGridPanel = new JPanel(new GridLayout(6, 7));
        inputFields = new JTextField[6][7];

        for (int i = 0; i < 6; i++) {
            for (int j = 0; j < 7; j++) {
                JTextField field = new JTextField();
                field.setEditable(false);
                field.setHorizontalAlignment(JTextField.CENTER);
                field.setBackground(Color.LIGHT_GRAY);


                field.setBorder(BorderFactory.createLineBorder(Color.BLACK));


                field.setForeground(Color.DARK_GRAY);
                field.setFont(new Font("SansSerif", Font.BOLD, 20));

                inputFields[i][j] = field;
                inputGridPanel.add(field);
            }
        }
        add(inputGridPanel, BorderLayout.CENTER);
    }

    // Start a new game and set up the keyboard if necessary
    private void handleStartGame(ActionEvent e) {
        model.startGame(); // Call model to start a new game
        if (keyboardPanel == null) {
            setupKeyboard();
        }
        keyboardPanel.setVisible(true);
        controlPanel.setVisible(false);
    }

    // Set up the virtual keyboard for input
    private void setupKeyboard() {
        keyboardPanel = new JPanel(new GridLayout(4, 4));
        String[] keys = {"1", "2", "3", "+", "4", "5", "6", "-", "7", "8", "9", "*", "0", "/", "=", "Enter"};

        for (String key : keys) {
            JButton keyButton = new JButton(key);
            keyButton.addActionListener(this::handleKeyInput);
            keyButton.setBackground(Color.LIGHT_GRAY);
            keyboardPanel.add(keyButton);
            keyButtons.put(key, keyButton);
        }
        add(keyboardPanel, BorderLayout.SOUTH);
    }

    // Handle key inputs from the keyboard panel
    private void handleKeyInput(ActionEvent e) {
        String key = e.getActionCommand();
        if (key.equals("Enter")) {
            if (isValidEquation(currentGuess)) {
                processGuess(); // Process the complete guess
            } else {
                JOptionPane.showMessageDialog(this, "Invalid Equation! Please refer to primary school mathematics books to study.", "Invalid Equation", JOptionPane.ERROR_MESSAGE);
                resetCurrentGuess(); // Reset guess array for invalid input without incrementing row
            }
        } else if (currentColumn < 7 && currentRow < 6 && !key.equals("Enter")) {
            if (inputFields[currentRow][currentColumn] != null) {
                inputFields[currentRow][currentColumn].setText(key);
                currentGuess[currentColumn] = key;
                currentColumn++;
            }
        }
    }

    // Check if the entered sequence of keys forms a valid equation
    private boolean isValidEquation(String[] equationParts) {
        //Simple algorithm to check the digits and "="
        return (equationParts.length == 7 && Arrays.asList(equationParts).contains("="));
    }

    // Reset the current guess to empty values
    private void resetCurrentGuess() {
        Arrays.fill(currentGuess, "");
        currentColumn = 0;
    }

    // Process a valid guess and update the UI based on feedback
    private void processGuess() {
        String guess = String.join("", currentGuess);
        String feedback = model.submitGuess(guess);

        // Update button and field colors based on feedback
        for (int i = 0; i < guess.length(); i++) {
            char feedbackChar = feedback.charAt(i);
            JButton keyButton = keyButtons.get(String.valueOf(currentGuess[i]));
            if (keyButton != null) {
                keyButton.setBackground(getColorForFeedback(feedbackChar));
            }
            inputFields[currentRow][i].setBackground(getColorForFeedback(feedbackChar));
        }

        // Decision on game status
        if (guess.equals(model.getCurrentEquation())) {
            JOptionPane.showMessageDialog(this, "You win the game!", "Win", JOptionPane.INFORMATION_MESSAGE);
            handleGameEnd(true);
        } else if (currentRow == 5) { // Check if it was the last guess
            JOptionPane.showMessageDialog(this, "You lose the game.", "Lose", JOptionPane.INFORMATION_MESSAGE);
            handleGameEnd(false);
        }

        // Prepare for next guess or finish
        if (currentRow < 5) { // Ensure not to exceed the guess limit
            currentRow++;
            resetCurrentGuess();
        }
    }

    private void handleGameEnd(boolean won) {
        int option = won ? JOptionPane.showConfirmDialog(this, "You win the game! Try again?", "Game Over", JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE)
                : JOptionPane.showConfirmDialog(this, "You lose the game. Try again?", "Game Over", JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE);
        if (option == JOptionPane.YES_OPTION) {
            startNewGame();
        } else {
            System.exit(0);
        }
    }

    // Start a new game, resetting the interface
    private void startNewGame() {
        model.startGame();
        if (keyboardPanel == null) {
            setupKeyboard();
        }
        keyboardPanel.setVisible(true);
        controlPanel.setVisible(false);

        // Reset the game board for a new game
        for (JTextField[] row : inputFields) {
            for (JTextField field : row) {
                field.setText("");
                field.setBackground(Color.LIGHT_GRAY);
            }
        }
        currentRow = 0;
        resetCurrentGuess();

        resetKeyboardColors(); // Reset the colors of the keyboard buttons
    }

    // Reset colors of the keyboard buttons to default
    private void resetKeyboardColors() {
        for (JButton button : keyButtons.values()) {
            button.setBackground(Color.LIGHT_GRAY);
        }
    }

    // Determine the color based on feedback for each character in the guess
    private Color getColorForFeedback(char feedbackChar) {
        switch (feedbackChar) {
            case 'G': return Color.GREEN;
            case 'O': return Color.ORANGE;
            case 'X': return Color.GRAY;
            default: return Color.WHITE;
        }
    }

    // Switch to CLI model view
    private void handleSwitchToCLI(ActionEvent e) {
        setVisible(false);
        NumberleCLIView cliView = new NumberleCLIView(model);
        cliView.launchCLI();
    }

    @Override
    public void update() {
        if (model.isCheatModeActive()) {
            displayArea.setText("Current Equation: " + model.getCurrentEquation());
        }
    }

    public static void main(String[] args) {
        NumberleModel model = new NumberleModel();
        NumberleController controller = new NumberleController(model);
        controller.processInput("Game Started"); // Notify controller that game has started
        NumberleGUIView guiView = new NumberleGUIView(model); // Create and display the GUI view
    }
}
