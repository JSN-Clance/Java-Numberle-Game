public class Main {
    public static void main(String[] args) {
        // Create a new instance of NumberleModel to manage the game's state and logic.
        NumberleModel model = new NumberleModel();

        // Create a new instance of NumberleController, linking it with the model to handle game input and updates.
        NumberleController controller = new NumberleController(model);

        // Send an initial command to the controller to process the start of the game.
        controller.processInput("Game Started");

        // Create the GUI view, linking it with the model to display the game's state to the player.
        NumberleGUIView guiView = new NumberleGUIView(model);

    }
}